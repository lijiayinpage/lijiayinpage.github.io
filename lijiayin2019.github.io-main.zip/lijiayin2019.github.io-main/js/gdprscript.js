// Script created for GDPR Compliance. Source code located: weebly/kings-banner

document.cookie = "gdpr-kb=true; expires=Thu, 01 Jan 2999 12:00:00 GMT; path=/";
window.AragornAnalytics && window.AragornAnalytics.initialize();
